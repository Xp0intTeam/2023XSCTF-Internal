# 名称
can you pass md5

# 描述
Do you really know about md5?

# 题目难度
中等

# hint
md5碰撞

# flag
flag{y0v|nDeedReA11yk$nwAb0uTMD5!~_~^_^}
