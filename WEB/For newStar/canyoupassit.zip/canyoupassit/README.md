# 描述
Do you really know about md5?

# hint
md5碰撞