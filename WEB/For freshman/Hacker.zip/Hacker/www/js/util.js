window.onload = function(){
    var h = document.getElementById("secret");
    h.parentNode.removeChild(h);
    alert("hacked by zeta!");
}