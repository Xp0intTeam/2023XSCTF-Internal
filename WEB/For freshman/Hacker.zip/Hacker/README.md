* **题目名称：** Hacker

* **题目类型：** WEB

* **题目难度：** 容易 

* **出题人：**pANz0e

* **考点：**  

1. javascript


* **描述：**  Admin的站点被挂黑页了怎么办，重要的东西都被删了TuT

* **flag：**xsctf{Y0u_can_no7_f1nd_m3_?}

* **Writeup：**浏览器关闭js，或者curl请求

