#include<stdlib.h>
 
int main()
{
    system("ls");
    return 0;
}