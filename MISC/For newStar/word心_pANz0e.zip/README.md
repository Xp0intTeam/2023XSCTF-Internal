* **题目名称：** word心

* **题目类型：** MISC

* **题目难度：** 中等

* **出题人：**pANz0e

* **考点：**  

1. word隐写


* **描述：**  啊~有东西跑进来了

* **flag：**xsctf{Y0u_g07_h@lf_my_h3ar7_g1v3_y0u_an0ther_h@lf}

* **Writeup：** word解压得到FLAG2，打开word最后一页，再设置里面打开显示隐藏文字，选中最后一页的内容换个颜色得FLAG1
