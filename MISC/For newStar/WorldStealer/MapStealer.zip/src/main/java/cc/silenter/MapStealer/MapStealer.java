package cc.silenter.MapStealer;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketEvent;
import com.comphenix.protocol.injector.netty.WirePacket;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.Inflater;

public final class MapStealer extends JavaPlugin {

    public Map<Long,byte[]> chunkData = new HashMap<>();

    @Override
    public void onEnable() {
        int chunkId = PacketType.Play.Server.MAP_CHUNK.getCurrentId();

        try {
            // Plugin startup logic
            File data = new File(getDataFolder(), "data.bin");
            if (!data.exists()) {
                saveResource("data.bin", false);
            }

            FileInputStream fis = new FileInputStream(data);
            // create a bytebuf
            ByteBuf buf = Unpooled.copiedBuffer(fis.readAllBytes());

            boolean isCompressed = false;
            boolean isLogin = false;

            while (buf.isReadable()){
                int packetId;
                int packetSize;
                ByteBuf packet;

                if (!isCompressed){
                    packetSize = WirePacket.readVarInt(buf);
                    packet = buf.readBytes(packetSize);
                } else {
                    packetSize = WirePacket.readVarInt(buf);
                    ByteBuf compressedPacket = buf.readBytes(packetSize);
                    int compressedPacketLength = WirePacket.readVarInt(compressedPacket);
                    System.out.println("Decompressing packet: "+compressedPacketLength);

                    if (compressedPacketLength == 0){
                        // without compression
                        packet = compressedPacket.readBytes(compressedPacket.readableBytes());
                    } else {
                        // zlib inflate
                        Inflater inflater = new Inflater();
                        inflater.reset();
                        byte[] compressedData = new byte[compressedPacket.readableBytes()];
                        compressedPacket.readBytes(compressedData);
                        inflater.setInput(compressedData);
                        byte[] decompressedData = new byte[compressedPacketLength];
                        inflater.inflate(decompressedData);
                        packet = Unpooled.copiedBuffer(decompressedData);
                    }
                }
                packetId = WirePacket.readVarInt(packet);
                System.out.println("Read packet id: "+packetId+" size: "+packetSize);
                byte[] dataBytes = new byte[packet.readableBytes()];
                packet.markReaderIndex();
                packet.readBytes(dataBytes);
                packet.resetReaderIndex();
                if (!isLogin&&packetId == 0x03){
                    // compress
                    isCompressed = true;
                }
                if (!isLogin&&packetId == 0x02){
                    // login
                    isLogin = true;
                }
                if (isLogin&&packetId == chunkId){
                    // chunk
                    int x = packet.readInt();
                    int z = packet.readInt();
                    System.out.println("Chunk: "+x+" "+z);
                    long chunkPos = (((long)x) << 32) | (z & 0xffffffffL);
                    chunkData.put(chunkPos,dataBytes);
                }
            }

        } catch (Exception e){
            e.printStackTrace();
        }

        ProtocolLibrary.getProtocolManager().addPacketListener(new PacketAdapter(this,PacketType.Play.Server.MAP_CHUNK) {
            @Override
            public void onPacketSending(PacketEvent event) {
                event.setCancelled(true);
                int x = event.getPacket().getIntegers().read(0);
                int z = event.getPacket().getIntegers().read(1);
                long chunkPos = (((long)x) << 32) | (z & 0xffffffffL);;
                if (chunkData.containsKey(chunkPos)){
                    System.out.println("Send chunk: "+x+" "+z);
                    byte[] data = chunkData.get(chunkPos);
                    ProtocolLibrary.getProtocolManager().sendWirePacket(event.getPlayer(),new WirePacket(chunkId,data));
                } else {
                    System.out.println("Not found chunk: "+x+" "+z);
                }
            }
        });
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }

}
