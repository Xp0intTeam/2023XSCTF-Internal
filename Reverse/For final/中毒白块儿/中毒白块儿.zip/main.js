window.onload=function(){
	asked=true;
	preparePage();
	Math.seededRandom = function() {
		Math.seed = (Math.seed * 9301 + 49297) % 233280;
		var rnd = Math.seed / 233280.0;
		return rnd
	 };
}

function generateAESKey(nums) {
    let keyString = nums.join('');
    let hash = CryptoJS.SHA256(keyString);
    return hash.toString(CryptoJS.enc.Hex);
}

function aesEncrypt(text, nums) {
    let key = generateAESKey(nums);
    let encrypted = CryptoJS.AES.encrypt(text, key);
    return encrypted.toString();
}
function aesDecrypt(ciphertext, nums) {
    let key = generateAESKey(nums);
    let decryptedBytes = CryptoJS.AES.decrypt(ciphertext, key);
    return decryptedBytes.toString(CryptoJS.enc.Utf8);
}

function encryptTextFourTimes(text, keysArray) {
    let encryptedText = text;

    for (let i = 0; i < 4; i++) {
        encryptedText = aesEncrypt(encryptedText, keysArray[i]);
    }

    return encryptedText;
}

function decryptTextFourTimes(ciphertext, keysArray) {
    let decryptedText = ciphertext;

    for (let i = 3; i >= 0; i--) {
        decryptedText = aesDecrypt(decryptedText, keysArray[i]);
    }

    return decryptedText;
}




function detect(){
	if (key.length % 4 == 0){
		pair = key.splice(0,4)
		GIFT_4_UU = aesDecrypt(GIFT_4_UU, pair);
	}
	if (typeof theScore=="undefined") return
	if (theScore > 62 || GIFT_4_UU[0] != "U"){
		alert("BIGGGGGGGG GIFT 4 UUUUUUU!!!!\n" + GIFT_4_UU);
	}
}




function preparePage(){
	speed=0.1;
	Math.seed = 6;
	theScore=0;
	GIFT_4_UU = "U2FsdGVkX19kYZXHmnfZP5N3AqUXdyz0peByd0vr7i4tT6Dt5IizrodMZpMV3cwXd65LYkfpqwW20rFKb6GcUTt8mmG/3BBAlOq2lkbxwyw/N7KzJ2qmOkRlbEah5KSgP07DpqytAsCkGzCJRHucyD15qZ2Ut+VXlCsEB7XbFlYHzWwqZpCkm9VcBhLjgfG3ur1wfVP+0lg0m8IVjq21OGTzsBSCUSbnzhbRgmX7JbftMJLLuORRZ55sDgjxhzjB7X7gej3KWlglO62LANekFTWKJn18DrGkrML2l+bCbP+4Y6pozylYdep++wlzQjGTUkeWDfDDbW8j7Eb5UwPf503u9hv9ERu/0km9DBvrNFYrWeQ2TPVi817691A5iutmXqejH/l+7thwkhVnEXz2Dej0Pn6fopyv1DcQRFGeIkEt8ttExo4w6+3XvYWGL++GB5qw88xU0vRJmzmp8IXayliJftVWwQkItcx9TWyL+ekJAO70dMv8LaWVhtXpiOdi+dP2O094hrVQ3lHM2Hgawm6qmSPBHEfkccmOXe8reN3iCaA5RETP2+X1nFSsfvR0gN26b6p8CR75sbNvCXVQLp3Z7wVPJPzojaPkC+od8fq2pbzRlYsvWMMhW8RnFJ9PtTXx+a+jQ7rMyLxEy3lGpG25XjRa7Ws8xv1tU685WEFfrlfJje7UWWXqZ8wqPJQLXFymPiCyPkTUMA3MyoxTGzoG65YRdHp6i/AFVvhuABTdZg7yLTwh7Z7G7n77spUT4y2UURNTSINB/KWscNqorw7uASGwQzifvjzu7btPPxntqHaAaY89rnRgfBn7RwI88O3eBPyQjxcI87aWr0c8GyEETjaUvariFlZbOwjG4id6BBBiZXo0e4B1mqn/bqhBwjp6vrgNCsJuvLrcRV3gztnMuPfxxxoiAmhWG41ziRuJKcL/QV0mRTCuJpMPPTwxm/VUDOpsW6+KvwOHdYsn6WffVNmRWA+9JT8L7VxHCMMdGtoWB2KXfqKQiWZHN8vaex+TG+r73+XHAzAwDS31iYFM4P2rQTewALPs7smcNeEF5TNfMgr13tWXJnFt3zWXh/swF/TE3n3n3WzXp1573mD5guAT7f3c6lewgIoF5n7MA2jd+fIYYc5Zk1JWT2Xu7KTooM8EkMkJJxwORj8OnfXpqWC2pwSHZdvqR3VObiC2pl+YOSYohEVHoFrC8aLAKgdweL01MKkaN44tbOBbZrsVHUsK2qhc1FifcGYov7o/6u5kPd1NZHci+dbE6uR9I+yvGjTZS1OCVEC/bP91DTsh9hleV5QV0pFVZiEVRcVlP7mkGTEQYn63W889MyUyqVq2g4gqhFlzNU7Pfyp8Xv6EhbomzaoJVVBz4Ulo5mx7VrZp466niH686aPETlXC1tfJUi59vPBlxrlxWoIZA+Gzg6nxesKNRgKjjbdFCOkHfWlihgb0xJdDK79EB4oYxhflacqzZnpqwZG4YgNg7xLUpQJIxr7MbIEHRZ6sdhqz7DI5osfGbldJ0wYM2YLvL6SvBTUCx4ghTOfZMEUMon7CNbz5QlJWLgy+aPVb6E/j6icRYW2XcO/9kxouWJbXRJvlk29HS8q2M8+RoDh7wLIzcH9Me6gEWZ00fG3KitNJlZC0TxKFb2Axney2lQVTw7WG4/mtqYHrULvOlktDoQe4mBuLuh2tee39pOO6sM/TzAykgr2MH73CaFCoeaMa8vj6e4yaJQ1cLi9bB8bUUCVIB2AuQvRGPCtJ46umYZiOBnm5Bs/EEPdtKndUvTdZ5awwX4X10ZabeWnoBDwRZIfuDqqpiiCo1v6XjH3lCleU71aL3HLipL1DCBpx6/J5c9qVAtYVr46hKo/EuYr6SZTjgsrnzjCDoMKB0SfHMlmbpRvoPsPVlilNghugS2jsn/f9aAk35ykGfyiUyPguTStkSlCztoq3Y3t/MaleMvkByuk3VkuuDLOHRV6GoqrgwkGVAhLsK9h79orXwuolQxVhwxz4TmXAYRdQ/uW1G957AT9wV7m3DSTNX6DVuz0smYoKamPbygV53YfFJ9R2I85w669ddqvX2oxru5JxFdM+nIQ4cEgFPY08DGzbg/X5jUxkrZoAJeN8r0g7PJQYcltagXoakHUzV6jBdvxJJWmlP6QWmXYlYI2MWxzstX1JCTFAJm2mJbeGrlt+GXFyI/Pyshnk6wpcUKth9HKlQ7ivJX3jUmbOZYfugWceOlyBp1oP9pJo3C3yRbztysP4fj0cs3yYwW4wXMkDy+ochsZtbIFR+wsI+IZkJe405iP8kvb9LmIX1MNsHNJiGoiuCaADOZyTU7SVfWCcON4xL72FUekDvs/v/X1RYdNtTstDEbYjRx9W1OeM778Xwk+vWUrMv7H5ys94OsSsO6AR0Jy4HL9XB9XouJOCnL9hSEi7618JNXOyuyveNf3h5TCo4lpc6T3klk7p4L65xVqjGPFs2OU/c7B94z4sWC98PUiyAhHIZz67H2a7dpeK8vh/Xu8pQ2LY3W7OcEBSIFH3gNINa2OY9XnJUMra5yt6kVnVUl51vitDpBln47v4ML0ar28Wb4piFbJx0zg+GAcQTSwr6gwXqlT3HtTW+n6i49jQCfnm8g/fx7hSZJio15tAxQPWNNwfSIa9mZdxdFDcUeKnCJqgD5tzn/T92U/J5qvWtzOAXzP2tUMfplumAztQdp9wX7evkTTmanmd9xMHY89g04bOXmMae5iWPt1PhZhfmXTG7CIvQPV6ALjkL/RWSmiO+GF+v9rdUvKFEapPm5aW37HS42DDfKA42AuNL2eyUWf45bsSvU5RWMOaCiHnPMaijigQynRhMcK/ST02lwl4ulFyh4O3BgsYDqlERFIjHWTzk5HGkOrcKcly75306DdCQ5Ag11nTZJX/82iXVJCaGnBt0Y0S9KxGtjPNY9Y05RUgOlVxrRaHyof40yJTQ0+/S4AeJDoUVQ65HdlUF+/o4l3w3RNopjR31fzqZINPBLAlQWlR9nWy+gAG57pRZKEWiAOiIccBywW6U8NVF30ZJlT5sTnx6UaGH+zHP5OXGpyFBlP2TMeUJWZANp0rogJVl857smP664KTGjxZvNSg3UwKs0yPabsmOimvRP5x0kxvMOvIqF09IFq16j0S+xVrAsOmyf6N39AFMMfR9lEqpnCHnAhpSRFU6Nb4dn87REKaa4uJEOrZxxG5WHPQwsYJEpQ014WApiyOx7mb2OlH2SrjA8K+GllmOm8v0dOA0MmIzpT4MGUaPvmmWZez9sbgeS+Dx1mkbxzkG+DGjNqvlitW/kyLmtc9Kv6wRPjvrNpxORyvmYOTTS3oyBkOiTFPMUBLOBTzxCtH2fmTVrjrj3h1tw94325Api9UFTPC624EytY+XQnJQSv/U8EvQchRTGj4zALqr4kQm920E5hy+TfDQKYvg2ap83nq9/HSAyjqYEmlrPnhYaEeppXRbTeKilQwI/Foo2HkY0Ae8cleA69HrK5jZKA5AwR3Vxatp962mKdya4CCkkb3TqfG60uDGOa6K2dXEJB+FeUJHTK2JyfIRtbzOgBWHkeArTpy2dPTup20dDs7E5XvaEadxfUpNiMAqcJKIFoc9aIMyyog1BmVIuH4Wg4lE7DxRSzYdpty3Z4ASxj2xe9TkZpD+NQle9dfXQ3Jm5mnwihS5xgH4AB8S3KNwWh9DHYn14HicTS0Qn0uRS2pS9o71LvvuRKHFhFKpEZVELrMKS2PMbEG3h57vzqIG4Lxv9B822XXFn2noo+gLfE7pjxxsVjoPTxtpNtBTfafDd8KoZcGX4MXJVZK+iVp3UxUcr9ySSml6MlM1/fWNyKMoNyU9Eymv1HpjPYKEHBR4JuiBpNSouKocypbJg6gsU6L5zjAjU5xEhvl4SXUtIV08s2DljOk1glC7iVpghkdzUqpTg1JJQyMuR+vewqtwFhTSPm87jNuf1EB+bqyUD+/QIGiQqn1rpS2yKrXP4Ajh/0hJJpJzYYlewDQ+Teb1CuZU0vK0Ge9b2M5UnOt4ZrGjR22ld/YyCub48LbxaMg5LHl5nqBk+IA4y9x71uz7Z3oRDdMhVwJ4WQWP9nUyxtiBrxWryk7sxQX/3ahC/8UKRgQmmOSA7/NxeTvbD+iF4Y22vn2vjwHDnaxSyo7wBNhhX8nGjqr8hUhqa7tWA0cLWARYoOzMpdVuzZ8aRUE6wifGePNVavYxOZgPMvMkH9DCiTSb/3TKGN8JZ/a1PCyCnVC027GrdnpYtsheUybgIFXrK7Kl1/l7wjS4MBgFj1edrldg0OKgPffrKlCHG4Y9WpKxe3fovlcOD5TIE0i/HgDdPq62x6OCJqx2iI65/1W6lm8pX/BqK93NWaZoI80ggIJLg2ZKenXuR0UMN1tEHlVxLAVrC/Q399muyuzpLVyHM8ks8A+CAcvJC93JvWUAAGV+Rfdt5xpJKkLh1LebofxMOuWmzW8h9WxOVO7FXJoNLksClMXTDjmWeSvqWx80i1Fe6wXTepurgD6JupjM6fA4h984WbcSXK1E3+6k8LzQAkdBkD5xuqoN7OJl2XOBcS0MwHrtPdDNPVoTI+zT+B2/kzdnAwuKjrEyUOhYDgRAhUTZaVfC2QtUIEFPNGLwpdpq9tByOploSHyj0U8UR2xQFBQpHl9vZ9bSXizhTMb4YCqYSpsCGY7UcWHcZj8lNIhTwazihGiFeBGwgLLrWBZ3zbHFljJS0liwBUBwVSa0du2YhU+kp+8zbA/GcIe8QLRe7iB2BtR386oJnvk2GDXxM3ra2SEvyZtvHt/kYmPvaah+PmlAoLpRRZ0htXb3DHwQ2blWCD7yLgfTWrkZj6oJ9vzgUifiyDemB6vkNTAqWUlQdvMBI9vQGcKJqfjxQ3omA2Mosq9835XbVOr6WJI6TgKvX3Uc1VnHTOjersX9v62DLaGuFMCt6U23fO40TTEoc1hrWwrhDDn5WqM2zRAimI7ZkdI4SoM6wNJfK8VnEXsQnG3Qbyn/5NGdtHx/MhYIFi8tiJ2pyORqAwxGaJQbU3wdCQ9F/nsjJnOalOtds7GtCKGva/DbKd2bdjXKFilPqDg+wZM0XXZdyLRFnvMP2tYQ/hjeJtqScR3XbM64Zj64jLfUU3DfILsd7x1njrojk30NVE+qdvUrladqW96UELOzRJN0PjTKz7Ar80vephKzWZHfaBTjV3LZyDO+5opRIZud7QUNjo4SLAVFsxSesqkt11QpMHgXbEMDyoT2HNwBMHH/64DzXCQIEtEl2sgJuqYsc5Fyokt8B6tFJAhymUQfqJFqa7tgo6PP3TY5zrhuSrTSq1ZVXsfkoD+8/LQVn4Cd9QqU32voDEGGzmR39X7YCPl0XLWurLHtQRStLbWpptFF874ffjmCEIkDnj1l0SVU35rgveplYN+7PLzd9LciiLRegB+P2kI4qsW3EFRhVaU3WyPTUNOltlpQUooCK/9t+9Z6UGcOpMBwrrt92e8zK47MChHL5U4tPfxMRWPGgZ88untZHtXQdhbVcinnQX6yaqGS2q/6xvWX+YeHwQuRKEYaCZ2ClG6x2ki+yliCFyxFvJJqRkec6KDkQi/jDS09GgO9TCOPmg43LDkabFH7smBSE2T6Od37/5h4m27u2wdEzHr+wJLoxwu+3H/h62jBqoDkU2+98SPNnvnKUTa7nWPocVks8xE49UeRDIYuUpyPvc/5qaao4wyk4qCLh2GqfsEeqKOrd4LvTR0v0wOhUNk0Oo51rFKVaVAI3FXzw6JCFZa/WjeOOZoiQB1m+voQEogU7ww2YFpd2n3tkyiVpXuts/k7A8/9yK/FRRlUTyylvdusZXdzBGuDNkxfwU56uTMArGtCsvaMhX17RUEaZfvXEZZEBGszLofls4LbU5R0OKB5jbC5QSYN1qmQ0RFiLD/k5fUndgCtDJSB3iB6S3YfTfG4nee+4AdzdmFurVawFU5/tq20uc1jIhX48yVgRFl3PjZKUujSNiYuKjsZ4bVzmOjAwDAEcwzVYmAuMNf5RuUas2hc1ktJ9vRl/3HuF9Jb4YA2VWFvZMt4t+Ovk6OQ6YH1eOjclIrk6zoX5KxxWcEK70ykNmtqKSt4fXDPmYrTRCWG0hwYDRkFQPgyGaRNA2Kiy8wh2dwp3Gbq7XZj/BaCWnTY3OrQ8tqeIOK5lHuNlQFv2prfFOlrgPcTAweWSnjxAIpZr7cRaXyOskkAYyuG8m977KzlEi0xj7KquUhDqto5jxtBLfuja4XfxUQBAhYB5mPszqFc2f6SSLpy+7lV5NO889Bxk05VV3m60Kmw56Mun6bzlXN5MJIH7maxB3DDZDX9lvrqG2TmiugQwrnUXfzc7ta2SFhJD/n4wc/tq/wvRqJ5Cq15+REHCZCGBHUDIVhAZzUTgVQCMWq3McGBi6MO0NNqA/hdFCvIOtHn9D2yuq76glml0Zm16f0SGH4UIZFzyHh1qX/0cESN2FZfa1hmFiGkZcXxzSpwPmiwr4rNQZuUr7ptRHuL7/lQPQJS0S/ku6r5S21HH/GafOXtqiuz3sa/WblSTjPAwrd8M1+cok94cOzMLA0QWdMY1MWPqZ7yADHZxnWwj5S17gay5CxpksXT4MeF2hugd9g+RlZ0cQW4BTW8obFb3eQa6HhQH+9oqlfPx05t/85mOCRnpk+l2UdZZ08CVk4kN8vAGpZC61QasPyeWBGo17dU6gqqpRnGuGrTD3qcRo7WxYPWBWyE1oh/CASYoYc/ZGhfjLfakjne/2cA+DGegWVoZzKMslSTZrrQo8N16IbKX2JQ2fXGV4RlKZLvQuBr860zKnpu6ZugexnjDizxSiHAZUWidqI2Wtv+W46GnUUNXMjOqcKqP8+fdJ5FkXdTcW2Cdrvv0EHEq8EdtgenRamejEL7orhlT2afMJF4+be8+LVl3BNXTJAuGVIZoaqeLpa3wAPr2f+JxEkjEWjG3WPSh9J2yNUWzb/FDllYPDiilhNltzbc98g0YsIZZAD1KEp4rObc3/FCAMEup1avPONH/cO3oUtHNXpg90X1EVh/dBI96TeNKtX5G7CsDZW5wvY2iF14fq9PXALTw9O8KXA2xLi4xcCs9oyyXwVdfS4cJqqMHua/YOZD2j1o8mcawIygoSkNJ5uBQ4S5JzIQz06H86v0UZYzQPDMKjwDTxoIszUXhgUXaVXd8QCdyoR3+8BJo2ZojR3f7Yr3GB/F6see2uzZl/K9xF2e9vx+Nha9fq4Bvrnr9XlvV4qP9OYNymNsyPurMJOMCbTNH1FpZnMcEVO7Nvr5NLXdyRPmOijudJzk6q4O2edRyulwcbq7v1JNhL7Frb4VO5rA8IE5DQRXmKEEc9YxkYACh7oEEF9uvxN0Ab2Egz91jaduceoiDq0Af9ejpSK6HXewfrs4iJUAvMH7ck3my8iTaDyGFMih2w4WXCYFhBJn05nCbUKQQEKQPnvrVZp14u2FIPRdGuqTQLIqwwtM5RTSp+ldWWDqSNrBf4+7y0PCDRCLvHzqXzGnwU9QUAwY+i7vPQm6G2SXWs0/MgDbJxDwTWJZZTaHU/O3GNf+C+Hoo9IFetoRvkhMpLKH5u52kC+9bennImEPXtOtXoxCcpezQzQ/EMQ/Rq8It+jxAfzRb/wl9t+P8V8NNR6oVqMMFkyUWBwFBTvFcvZVcxUZQag6srLK55Ka2sWfTl/xPWpt95xppie1kpaP3qSU2zKAb5y8dtp9s5jbX1S7x9KwEiDiWDKUCcEKvhOBpiEnuK9qXZ2z1NkfbeyIj5l/6irNSLmsFqrLM2J6JZTvirJJFVPBB4Uxlw9yfVuinsdViOOOxSFUHSEXmLASeiMGHjWMVNYCRYy+SN5eEPd013P/gmeLtFK3sPv4ymuzcJA9N9jQ6AtVEt6SdtIbGkkJzu9FnS/wi5stq34MLr9irPCnYkudOBJMjoPYwsVoIewIWABldz/jJHMYFR2FrjgMWrAwxAXerzKIJLuqu5pS3E10OHFb7iBDVrMDbxigi+V0R+bXCNJfY/fe3WuERSi5HR1s8YzcPDRXO9/35fCdzlN4/OMsa+hYyZ69JPEUD+tgavgaMwPM0+fr8+hFQLQx9hBBoDj6/tSJ/hs9vZNLLlRpSXdABZGh90DxXD/NzyyG3mNqg2Y7zWr7FKa7H0Tg8IRw+CDfgEUt2/5rE81kn8nw2o4Hfi7dIFG/uZZCoehvzBR2FKz0LmruCYDK/Ms6cUl+kboaUbeF0W2xFMtSObF1kZvt38Wtwdo4IkhT1wSydmo1euuecmr2vE3SmiTeruRXR5nk4Mfvvh2ICv7Wl2gtk+apzqeWcjP0v7MXA4zy8BC8YkGfh2jYWLduVcnSp5el7rblq1CuSVHM8rhQhrF+dzLnA9WukCthoBXZSiZLffSPpqgijud5ENShEcRtTkww1mSvnan+thTLDvIQh6eKDHyRIAFOdae1Hw4YRF+FOCwZg7qYwjOT4PwJITLmazRvZ4+WmQ88aKcFcXHiJhzI2+K55RU6xUNEpOrzOCxQjoCTNOTZQPgu2b/qByv9OGePqWqpdneUPWb2e30RmiAbNwyRNJy2UJalg8G8DP93MtvYxiOIS9SPnurUWwu59O+qIZxZHe9uFH9coPtCC3lkmXDGQgSL5YQVudfeGDU5hzI4Snf27lpC9zsR3ZJJYRD6JlU4n6yL8XxXwUCFhn2/aZYW3rNRU3GPIziPVQTd70DDQDu+6zAv3XQts4LXZW5RYsajwH7qZLO7a7bOVaZ8f6wjLepY0nFZaInF+iQLQxlwFRM51yH3ddMqyWwDAwBSk4CWa1v4gev/ABAa+q93JnVw7mL3zh+5Vulf7r2cAUv7mloUq+7VpNOb3JTDT5WpCD9DMznzN0uIddBupe+8q65LAE+CPcuyP6yMufSbCQYt3LMYFWx61ASQppC2LZj68gYUgFmZl585F10D7BaRLQ5eMde0G4WNbELxNo1JbF7cURZWCKWLfwxqwfeh0JBOqgVdvdVw1LTzZq7ewD6V0FWN0ECziMzVRXWZmUpeykNyZmYxpA4KQnnOnaZyGeaW79oCgZ6yzG+j60Aw9A0bfehFEqTbLK8MuRdgvJ0+4sjakLdx5JXsXrLsCWaOi//X8i2dL7wm6EwKW3lSa8rQP7F+nn6WI9RfNAoma2VNKnA5l6kFvxCqCmBpdmT/dKT7obP0e/rrpttxdWorF7oKC6AdHvd/xSl/XLIQe8VuzlbC27yBKWTnAhEpOEwy3gZy0aMojNWT6+47thKHgNVizlhW6Zp5O9aWcdzjV28JWJYQK0PyY6mi4ApoaxlyYfNzEIXGtV8vioYaFUWigj/n9Q/4SXXmzaBZCNkqtw08vj+lqi4hHSRgc4XIXe/TWr212N9gWe+vfr/SF77Q2pKsKb3/vMx0jqFJUbhHkIotEMUqv56xin8Zm6SCWYjipZ504lDDZ8LnF3LImyxoNroUc6z6KBv2J75h9QFuLK+9wY+Gest9hJXIAjvdxxKBq3qH9f60Fh586szngcbqYZxyxtc58tkLCr/kufcdGB4xUg/F+W63deLOvy8Si6qP5ORyuyvCwQZxMetiEmCVLJcM+jUmM4FUqmkNgxT96CJG3xCAGBJMVj4ksWkXed8hDXfBu1ynbmVpQ5IBYxA9Bc37bn2Ba3Y9XT/EziNpt8X/BY8j/+loMWI0EhDqeOr3SwF1+CwYm7/DjpGTXjfqyBJGqgWdRSKCB1C1hE4ZkYju0hhGlmv4pxjegSr4WnAqN1rg1duNU1UcnCBgitjVU/O4z8W/Q1hJS7bfPVYmgNb+Bh1urUQMm6cwr36yJkBy0oIy5r9D7OsVwH+YJJXy74DKqqV14BXl7H6iBi/JwxIDPjdeZnQw55QHAjQyKyFT1cdJWQSBuTawPl9oF6r5nDDisUKqjTDaSnA44r8r2O/IGdfX0uqc+SiJWG92zrHSsb3k60WRvAkqydon1WGBS3P6bXfFbdXhfJLCISqhbKX3vcxdAKih9Z/grPCnezjs6WiSo/WGdr71o3fgxINGfTF9nWOkqjuxixPOKIC8JLqLNJvTZE5WTDFouQFoy43fddWHXlNFeyO0kPpKuTT8O4RTb/YLOvjSRZyztZVu4sLz2LxmvKAi1imAlo7S8aNSTlkEL6M5m5FQDW00cpS24Bwl7uwQQ1bbeDwRk/8tULVnF8oBoAK+Ki39OrVJbZqQPHi7UbGviC8B9MrSxOJbgO/NLFeQs9xCwgCiqGvs5wEZgCFof4h66D9O9vt36CuSkW1mmK5Im3cCCMChIzqxc7GPzX3Y2CgxIFTLqzBvtmiIjTAecXqxBYZiSISTtIfho8M/x8Owgoxj+5TO9+ITXvBResWv4au6w9K+g50CQkE42c7eBpK9Hk8FMiBUERp5525olRMPkVNbQE94M1UBLo/I5SA98HsrICDhShpv5tnxzkhBajH3jmKSO3yhowTcL5IRIaieddCOVXQBiYsQmvkACtofjueKqwJUkujxMxnWNQlnVWMW8m8y7xMioI0epqOQKiWxlC/hUOYy9jP/uNm29EaYxBp7i+vVuJLU2Gack4cvJEztIo/twnIoTumKR8m0/ZHdIkYRRANrKINtjC3LKhU4lOheFIW5SpcjWFDfX7GGu3tD3YxCgnRAgI3P3WAeEEIwa2Yx/YenuVOvcYBR7nFboOa+1ilvSYsIoWAHBni4ORkyGEWA2dM+poE2rk6/ZMVqbrXTLtR3ngr0ez+ITXKy36f3JRWWxZMCGNU2IMER/qS/XGJwxYuKdRVilamOUjLpFCf0K4+XfOJYwAJr9QRrYBXDsK1+3TE+3RetiqQGatckHrTqqdH7ymVHe3LvWvxxmijAX7Izqi4A4s3U4+RXNx5cOhRipsqijlQ/U/XYQwCi2RAdIPcaAiQMNveqNAhbakU3WGSsrijGJevJHpZC+T9yOTTzSirNMdmxkRpyBnpSK4B2kf9MLQg8TLnqma1KS6GqElJIb3NpHa27S9/s+K42nYCBTgsf3f/kiSXHeW8KC/WpbzO88Q68MRGMp376NADWSd5U47Z+QId5YsEFg5vbJl5dCAufvM1QASVWXhjrfy5Fv/kyB9f/ejBsHgAkE1XIuND9S+XUqP1BsYjW8kiINuCSVonRdF9WCqquC7NpIfxxItbjBMu4zXmV6QidQXP5TPAXCA+OdSG9kjRdTN2Ru8Ahvtw4fC0wLnZ8jmtiFQhsaVtGW5vlnEwBtxbUdJnSk8zraq2vsaWk40J+q1tGKu+IaFx3arCpt/ft94xHGrw4OSF4sgu0L3pLALwsTcTH5UK7/K8YEnmukxN63NfTBoBtSzGtaVr+yM+uaNqddTPvn5RRrjCfdif0+wdDK0M4cAbJWOMj8ss/FAbkHYjGsc7C8UVHnrxrKGO7hSnzprFxBvNTafEzgI6ETd1PTxJQI46yPDpx96BkLZRZH+yurNeHr5szJJntf98C7EcgUn+f6/7eN4nTW7cvVH3CZVuM5Je9g7S08K920TuDICGBlyiXWm7aW2ZiMDiL50asuRokNOqQAqUJE9+bHFIPVeR/nC78DU6gwPxyQeYyofQieU0z058gLwwUfKa7M357OwtgZCbeCWidaTwSnp9PVugnK8hcAaREBKSNAe1LucHIVFH0nIARodTk3snCpx8I+kb75t2MdreEhyBdtf0xbQRiz1WyytwG0LOZaXAPlbbayV3j5WUhK1YTzZN0fYsvXZuowvAwtqnEVHRy2Kn+ULe2TlEFhPI5LBsQUvYpZZbbOPef/G6iECKBpojNC/tGnQ1XGUyKhEDT3SlJLvIG/613rbl7mlFgQ9GPXgPMvgFVyxRJ9ViI6FU6+rUwjDXVDgTmU5lIZwTz4KSYaGkUh/4r7Ddf1NLclSTbeOJ5YJff1SI+G8IyKqnn+SXfLRwb3KUJkicjCyVcvOypilyL+oAxoQ5CEWK0Bym/+d4cknpZt3BQDxbpimNL/aY3neG0RVtAcnG8110IpdFP+KUcOvsDn8cqMIYf+Qmni35jQwuRPobVMk9ss0oXkWcRyQwFTL1h2pXTDjJmyXWkl7YZXJWyz9wlfE7BqptMMc5ajyx318YNq+zLOGCkVso7cvnsNg3qJJYjCJZbYEwtyCy77D1IpoFRKj9Rv2wO9iUHPTr35Qds0dkSQ2Ptiv9OyHHz51HgrmQVYSgZNMtzMmdb7E/gQSFZlCNzRxYPZPttEqK71Ivj61rcXDmmGUA3PO5o5HHwStfzPPAEJQXiZu28h8WNNrc0Lvc8OasNKxNWvyQmp04OKWj5b1W1JhqCuAovwCwnNQM3w9HTTQK0/MZtjwUbTJvd/K5VoXMHibpeNKs8dtEbbb/97tVz91mz/mMhUfCMpNC6zLkOss4mqRWn55WRqlo5V3bSlJsdYYvRsxl95bhkOfMEDiGjzV438peYX6n50fygUy9wQGdu4HQVtpb3GhEtKpOM5hH4mEiOgn1iPZ7k1FZ2/LRj5xX5rBtiynH1bnCXAlsfL126TQZQC2RCiwYn1yu1ImATh8tC7bdC86j4Vkofmte4a8DYcryu5J2eiXbKLCGTH7FgiRlgaJBZL2P2JkRmVVdWZEbIby1KODYczPuciTjAlnocsL2112Hq8Q00IHmb0VSUtDEh4UPZ25hZWSxc/JCyUSXfId9rvQR1pu74C42rtCW8yAgPQVMKQMienvfBKtfTWhyxJB+oBrHHBsrv/o135P2qjNPD0MtKqHs4RDBCq7N2aLWPiPGbvItiSYy/K0uBWyoqublk0LBwOGMNforInM/jCo5EMm69W2DEQFfyEi6024wdNuPKi1s6SXEvaNsdySh9VG21sj/9LQP3tDJ8HYdhOH/4zkhlAyQ3pVEPbnGaOPg6oq7VxY8pPkcYVto+kf9vtDq9DHexK7pjX/nbHqgbNVQxZq1v1lva3gFQFi38tyf0cfEiqTgx2lC63iM/xGAVD6+N0q7bp+fAhwvAYPgANycSegVvOYK8Uh2vIh+m8KNsiIr8Gf7vndw7ForlkCh8z/y6yxaMz3HBn3A7YPuo96y3fhR7qsngXYoGju/d9zLaSavpGZTZ+Thd+HCL4EAgGXrkHvIDty2pJMlWtslKSBkXHjtcV30SbS7VRrXn3eU/E42YRmEj+G1dUnfZB6PkQx9v3+NZe8Hkh26TNMxUwqw9LPVcp10x9Dw5RApaUWnHk3LEFrcg0b/Xbb6F0hLniYGXDYQ3CakPD7LUP2iLFMbPftBe7u0PnVWDXfrgI0cGzVwmNx6a1aDU5zcVcjQJ4kn8iIXWiafgi/Z9XiQArLCUrTIzfsHGIX+DFU+0Pf+s5xmun91pevgK0wRxW9TaCyrErFFBin7xIFijtIaL5Ri4fu+7UUUeqZvrq+fM63vE1TdixFcNu+hWPp5QYXks7Cw9GmDnR9CpgYw+rB5MxDJZyK6B77WITB+fppwxrQY5ReztK43mij5PmULujS/3P00D16hsp1j2yo7BtOjFx5JlPfIg3zC0LQnoua5gjNJLJHUJIQ+tdIZHFAwYL5GduyxrFFl1gjfDy25WUv/S96yWAwQPMPUjLT1c84yJblz7qV+KYovoB2qgaFFqwJjAx2TFUexYgqBjBq8mqBGtUJV6ywt4D+ae1PeCSz1f4VvyYri2qzVlnsMW1EW+Y9WW6u0NoTGJ/kFVKpMmaujwM7fdeI6vDcpk7fzD0FiqkqhP7DjvnDFsnLibz2sTrukCPrmc4Da7AM+ezWtMmZ8GLTNGQTCzZwx60J1z8XGUXDkFQb7CVGJ996V6dLFWUXge9fAvzwK66721yi1PMcyMrx0kSEIEIFTv5mzWGyuZb33fpBQ0IQ="
	key = []
	$("<div id='prepare'></div>").appendTo("body");
	$("<div class='prepare_start'><br/>Click to start</div>").appendTo("#prepare");
	$("<div class='prepare_sets'><br/>Settings</div>").appendTo("#prepare");

	let start=$("#prepare div.prepare_start");
	let set=$("#prepare div.prepare_sets");
	start.css("top","20%");
	set.css("top","40%");

	start.click(function(){
		pageanimate();
	});
	set.click(function(){
		sets();
	});
}
function pageanimate(){
	let chance=localStorage.getItem("chance");
	if(chance==0&&asked==false){
		asked=true;
		return;
	}else if((typeof chance=="undefined"||chance=="null")&&asked==false){
		asked=true;
		return;
	}

	let start=$("#prepare div.prepare_start");
	let set=$("#prepare div.prepare_sets");

	let speed1=Math.ceil(Math.random()*500)+500;
	let way1=Math.ceil(Math.random()*4);
	let speed2=Math.ceil(Math.random()*500)+500;
	let way2=Math.ceil(Math.random()*4);
	switch(way1){
		case 1: var move1={right:"100%"};break;
		case 2: var move1={left:"100%"};break;
		case 3: var move1={top:"100%"};break;
		case 4: var move1={top:"-50%"};break;
	}
	switch(way2){
		case 1: var move2={right:"100%"};break;
		case 2: var move2={left:"100%"};break;
		case 3: var move2={top:"100%"};break;
		case 4: var move2={top:"-50%"};break;
	}
	start.animate(move1,speed1,function(){
		set.animate(move2,speed2,function(){
			setTimeout(function(){
				$("#prepare").remove();
				csh();
			},Math.ceil(Math.random()*1000));
		});
	});
}

function csh(){
	$("<div id='main'></div>").appendTo("body");
	$("<div id='con'></div>").appendTo("#main");
	$("#con").css("top","-25%");
	for(let i=0;i<5;i++){
		let num=Math.floor(Math.seededRandom()*4);
		key.push(num);
		detect();
		$("<div class='line'></div>").appendTo("#con");
		for (let bo=0;bo<4;bo++){
			let nb=$("<div class='block'></div>");
			nb.appendTo("div.line:last");
			if (bo==num){
				nb.addClass("black");
			}
		}
	}

	$("#main div.black").last().text("Start").addClass("startBlock");

	$("#main div.block:not('#main div.startBlock')").click(function(){
		click(this);
	});

	$("#main div.startBlock").click(function(){
		start();
	});
}

function move(){
	let con=document.getElementById("con");
	let top=parseInt(con.style.top);
	if(top + speed>0){
		con.style.top="-25%";
		dline();
		cline();
	}else{
		top+=speed;
		con.style.top=top+"%";
	}
	moving=setTimeout(function(){move()},20);
	typeof times=="undefined" ? times=1 : times++;
	check();
	if(times%(10)==0){speed+=Math.ceil(Math.random()*1)-0.1};
	if (speed>1){speed-=Math.ceil(Math.random()*30)-0.1};
	if (speed<-1){speed+=Math.ceil(Math.random()*20)-0.1};
}

function check(){
	let chance=localStorage.getItem("chance");
	if($("#main div.line:last").children().not("#main div.line div.startBlock").hasClass("black")){
		if(Number(chance)>0){
			$("#main div.black:last").removeClass("black")
				.css("background-color","black")
				.fadeOut(1236);
				chance--
			localStorage.setItem("chance",chance);
			return true;
		}
		lost=true;
		clearTimeout(moving);
		$("#main div.black:last").removeClass("black").addClass("red");
		playMusic("err");
		setTimeout(function(){
			lose();
		},Math.ceil(Math.random()*1000));
	}
}

function cline(){
	$("<div class='line'></div").insertBefore("#main div.line:first");
	let n=Math.floor(Math.seededRandom()*4);
	key.push(n);
	detect();
	for (let i=0;i<4;i++){
		$("<div class='block'></div>").appendTo("#main div.line:first");
		if(i==n){
			$("#main div.line:first div.block:eq("+i+")").addClass("black");
		}
	}
	$("#main div.line:first div.block").click(function(){
		click(this);
	});
}
function dline(){
	$("#main div.line:last").remove();
}

function start(){
	lost=false;
	move();
	click($("#main div.startBlock")[0]);
	setInterval(function(){
		removeOldMusic()
	},1000);
}

function click(which){
	if($(which).parent().index()!=$("#con div.line:has(div.black)").last().index()){
		return false;
	}
	if(lost){
		return false;
	}
	switch(true){
		case $(which).hasClass("black"):
			$(which).fadeOut(400);
			$(which).removeClass("black").addClass("grey");
			scored(which);
			playMusic("normal");
		break;
		case $(which).hasClass("grey"):
			return false;
		default:
			playMusic("err");
			$(which).removeClass("white").addClass("red");
			lost=true;
			if(typeof moving=="undefined"){
				theScore=0;
			}
			clearTimeout(moving);
			setTimeout(function(){
				lose();
			},Math.ceil(Math.random()*1000));
		break;
	}
}

function scored(which){
	if ($(which).hasClass("startBlock")){
		which.innerText="";
	}if(typeof theScore=="undefined"){
		theScore=0;
	}if(typeof localStorage.getItem("bestScore")=="undefined"){
		localStorage.setItem("bestScore",0);
	}
	theScore++;
	if(theScore>Number(localStorage.getItem("bestScore"))){
		localStorage.setItem("bestScore",theScore);
	}
}

function lose(){
	$("#main").remove();
	$("<div id='lose'></div>").appendTo("body");
	$("<div class='score'>You have got: "+theScore
		+" scores<br/>"+"</div>").appendTo("#lose");
	$("<div class='again'><br/>Continue</div>").appendTo("#lose");
	$("#lose div.again").click(function(){
		$("#lose").remove();
		preparePage();
	})
	alert("Reach 64 score and the flag will appear soon!!!")
}

function playMusic(zzz){
	if(zzz=="err"){
		var which="err";
		var houzhui=".wav";
	}else{
		var which=Math.ceil(Math.random()*5);
		var houzhui=".mp3";
	}
	$("<audio src='msc/"+which+houzhui+
		"' autoplay='autoplay'"+
		" style='display:none'"+
		"></audio>").appendTo("body");
}

function removeOldMusic(){
	let oldmusic=document.getElementsByTagName("audio");
	if(typeof oldmusic!="undefined"){
		for(let i=0;i>oldmusic.length;i++){
			if(oldmusic[i].ended){
				$(oldmusic[i]).remove();
			}
		}
	}
}
