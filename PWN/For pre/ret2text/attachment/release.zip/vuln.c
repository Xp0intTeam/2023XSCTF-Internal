#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

char *argv[] = { "sh", 0 };

void
readline(char *buf, int size)
{
	int i;
	for(i = 0; i < size; i++) {
		read(1, &buf[i], 1);
		if(buf[i] == '\x0a'){
			buf[i] = '\x00';
			break;
		}
	}
}

void
vuln()
{
	char buf[0x10];
	readline(buf, 40);
}

void
backdoor()
{
	exec("sh", argv);
}
 
int
main()
{
	vuln();
	exit(0);
}
